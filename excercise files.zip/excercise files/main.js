function validateForm(){
    console.log("inside validate form!!");
}